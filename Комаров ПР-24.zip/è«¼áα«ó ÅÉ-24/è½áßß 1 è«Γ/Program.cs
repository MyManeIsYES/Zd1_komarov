﻿using System;

namespace Класс_1_Кот
{
    class Program
    {
        static void Main (string [ ] args)
        {
            Cat murzik = new Cat("Мурзик",12.5);
            Cat barsik = new Cat("Барсик",123);
            murzik.Info( );
            murzik.Meow( );
            barsik.Info( );
            barsik.Meow( );
            murzik.Weight = 0;
            murzik.Weight = -10;
            murzik.Weight = 12;
            barsik.Name = "123";
            barsik.Name = ",fh123";
            barsik.Name = "Басиккккккк";
        }
    }
}
