﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Класс_1_Кот
{
    class Cat
    {
        string name;
        double weight;
        public string Name 
        {
            get { return name; }
            set 
            { 
                bool OnlyLetters = true;
                foreach ( var ch in value )
                    if (!char.IsLetter(ch)) OnlyLetters = false;
                
                if ( OnlyLetters ) name = value;
                else Console.WriteLine($"{value} - непралиное имя!!!");
            }
        }
        public double Weight
        {
            get { return weight; }
            set
            {
                if (!(value<=0)) weight = value;
                else Console.WriteLine($"Вес кота не может быть отрицательным или нулевым!");
            }
        }
        public Cat (String CatName,Double CatWeight)
        {
            Name=CatName;
            Weight = CatWeight;
        }
        public void Meow ()
        {
            Console.WriteLine($"{name}: МЯЯЯЯУ!!!!");
        }
        public void Info ()
        {
            Console.WriteLine($"Name: {name}\nWeight {weight}");
        }
    }
}
