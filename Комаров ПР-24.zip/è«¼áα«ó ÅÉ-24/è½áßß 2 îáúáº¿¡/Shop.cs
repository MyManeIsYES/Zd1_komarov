﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Класс_2_Магазин
{
    class Shop
    {
        Dictionary<Product, int> products;
        decimal profit = 0;

        public decimal Profit 
        {
            get { return profit; }
            set 
            {
                profit = value;
            }
        }

        public void setProfit (Dictionary<Product, int> products_Basket)
        {
            decimal newprefit = 0;
            foreach ( var product in products_Basket )
            {
                newprefit += product.Key.Price * product.Value;
                products [ product.Key ] -= product.Value;
            }
            Profit += newprefit;
            products_Basket.Clear( );
            setProducts( );

        }
        public void setProducts ()
        {
            //products = (Dictionary<Product, int>) (from i in products where products.Values.Count != 0 select i);
            /*foreach (var product in products) 
            {
                if (product.Value==0) 
                {
                    products.Remove(product.Key);
                }
            }*/

        }
        public Shop ()
        {
            products = new Dictionary<Product, int>( );
        }
        public void AddProduct(Product product, int count)
        {
            products.Add(product,count);
        }
        public void CreateProduct (string name, decimal price,int count)
        {
            products.Add(new Product(name, price), count);
        }
        public Product FindByName (string name)
        {
            foreach ( var product in products.Keys )
            {
                if ( product.Name == name )
                {
                    return product;
                }
            }
            return null;
        }
        //form
        public string Sell (Product product, string message)
        {
            if ( products.ContainsKey(product) )
            {
                if ( products [ product ] == 0 )
                {
                    message = "Нет в наличии!";
                }
                else
                {
                    products [ product ]--;
                }
            }
            else
            {
                message = "Товар не найден!";
            }
            return message;
        }
        public Dictionary<Product, int> AllProducts ()
        {
            return products;
        }
        //console
        public void Sell (Product product)
        {
            if ( products.ContainsKey(product) )
            {
                if ( products [ product ] == 0 )
                {
                    Console.WriteLine("Нет в наличии!");
                }
                else
                {
                    products [ product ]--;
                }
            }
            else
            {
                Console.WriteLine("Товар не найден!");
            }
        }
        public void WriteAllProducts ()
        {
            Console.WriteLine("Список продуктов: ");
            foreach ( var product in products )
            {
                Console.WriteLine(product.Key.GetInfo( ) + "; Количество: " + product.Value);
            }
        }
    }
}
