﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Класс_2_Магазин
{
    class Product
    {
        decimal price;
        string name;
        public decimal Price { 
            get { return price; }
            set { price = value; }
        }
        public string Name { 
            get { return name; }
            set { name = value; } 
        }

        public Product (string Name, decimal Price)
        {
            name=Name;
            price=Price;
        }
        public string GetInfo ()
        {
            return $"Наименование: {name};\nЦена: {price};";
        }
    }
}
