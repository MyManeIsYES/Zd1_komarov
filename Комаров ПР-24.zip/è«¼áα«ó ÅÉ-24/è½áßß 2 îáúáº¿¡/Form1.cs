﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Класс_2_Магазин
{
    public partial class Form1 :Form
    {
        Shop shop;
        Dictionary<Product, int> products_Basket;
        public Form1 ()
        {
            InitializeComponent( );
            shop = new Shop( );
            products_Basket = new Dictionary<Product, int>( );
            profit.Text = $"Прибыль: {shop.Profit}";

        }
        private void Set_listBox1 ()
        {
            listBox1.Items.Clear( );
            Dictionary<Product, int> products=shop.AllProducts();
            foreach ( var product in products) 
            {
                listBox1.Items.Add(product.Key.Name);
            }
        }
        private void Set_listBox2()
        {
            listBox2.Items.Clear( );
            foreach ( var product in products_Basket)
            {
                listBox2.Items.Add(product.Key.Name);
            }
        }
        private void button1_Click (object sender, EventArgs e)
        {
            if (textBox1.Text!="")
            {
                bool b = true;
                Dictionary<Product, int> products = shop.AllProducts( );
                foreach ( var product in products )
                {
                    if ( product.Key.Name == textBox1.Text )
                    {
                        b = false;
                        break;
                    }
                }
                if (b)
                {
                    shop.CreateProduct(textBox1.Text, numericUpDown1.Value, (int) numericUpDown2.Value);
                    Set_listBox1( );
                    textBox1.Text = "";
                    numericUpDown1.Value = 1;
                    numericUpDown2.Value = 1;
                }
                else
                {
                    MessageBox.Show("Такой товар уже есть");
                }
                
            }
            else
            {
                MessageBox.Show("В поле название товара нет названия");
            }
        }

        private void listBox1_SelectedIndexChanged (object sender, EventArgs e)
        {
            Dictionary<Product, int> products = shop.AllProducts( );
            int i = 0;
            foreach ( var product in products )
            {
                if (listBox1.SelectedIndex==i)
                {
                    label8.Text =product.Key.GetInfo()+"\nКоличество: "+product.Value;
                    break;
                }
                i++;
            }
            
        }
        private void listBox2_SelectedIndexChanged_1 (object sender, EventArgs e)
        {
            int i = 0;
            foreach ( var product in products_Basket )
            {
                if ( listBox2.SelectedIndex == i )
                {
                    label7.Text = product.Key.GetInfo( ) + "\nКоличество: " + product.Value;
                    break;
                }
                i++;
            }
        }
        private void button3_Click (object sender, EventArgs e)
        {
            Dictionary<Product, int> products = shop.AllProducts( );
            int i = 0;
            foreach ( var product in products )
            {
                if ( listBox1.SelectedIndex == i )
                {
                    if (product.Value>=numericUpDown3.Value)
                    {
                        products_Basket.Add(product.Key,(int)numericUpDown3.Value);
                        //products [ product.Key ] = product.Value - (int)numericUpDown3.Value;
                        Set_listBox2( );
                        numericUpDown3.Value = 1;
                        break;
                    }
                    else
                    {
                        MessageBox.Show("Нет такого количества товара");
                    }
                    
                }
                i++;
            }
            
        }

        private void button2_Click (object sender, EventArgs e)
        {
            shop.setProfit(products_Basket);
            profit.Text = $"Прибыль: {shop.Profit}";
            Set_listBox2( );
            Set_listBox1( );
        }

        private void label7_Click (object sender, EventArgs e)
        {

        }
    }
}
